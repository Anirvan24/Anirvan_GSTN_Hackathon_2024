import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import numpy as np
import lightgbm as lgb
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score, confusion_matrix, roc_auc_score
from sklearn.preprocessing import StandardScaler
import pandas as pd
import pickle
import warnings

# Ignore all warnings
warnings.filterwarnings('ignore')

# Please load the scaler and the model below:
# The scaler has been trained on X_train and will be used to scale X_test before fitting to model

with open('D:\Anirvan\Hackathon\Anirvan_GST_Hackathon\scaler.pkl', 'rb') as file:
    loaded_scaler = pickle.load(file)


with open('D:\Anirvan\Hackathon\Anirvan_GST_Hackathon\model.pkl', 'rb') as file:
    model = pickle.load(file)

X_test_path = 'D:\Anirvan\Hackathon\Test_20\Test_20\X_Test_Data_Input.csv'
Y_test_path = 'D:\Anirvan\Hackathon\Test_20\Test_20\Y_Test_Data_Target.csv'

# Load the dataset, please define X_train_path and Y_train_path
X_train = pd.read_csv(X_test_path)
Y_train = pd.read_csv(Y_test_path)

# Selecting columns with high feature importance
columns_to_check = ['Column3', 'Column4', 'Column5', 'Column6', 'Column8', 'Column14', 'Column15']

# Create 'Column26' based on the condition that at least 6 of the above mentioned columns must contain data
X_train['Column26'] = (X_train[columns_to_check].isna().sum(axis=1) >= 2).astype(int)

# Now we will Impute all NaNs with various approaches based on the nature of data

# Dropping column 9 due to high nul values
X_train = X_train.drop('Column9', axis=1)

# Fill missing values in Column14 with 0
X_train['Column14'].fillna(0, inplace=True)


def process_column_with_threshold(column_name, df, threshold):
    """
    This function ignores values greater than or equal to the given threshold in the specified column,
    and imputes NaN values with the mean of the remaining valid values.

    Args:
    - column_name (str): The column to process.
    - df (DataFrame): The DataFrame containing the column.
    - threshold (float or int): The threshold above which values will be ignored.

    Returns:
    - Updated DataFrame with NaNs imputed and values above the threshold ignored.
    """

    # Step 1: Ignore values greater than or equal to the threshold
    valid_values = df.loc[df[column_name] < threshold, column_name]

    # Step 2: Compute the mean of valid values
    mean_value = valid_values.mean()

    # Step 3: Impute NaN values with the computed mean
    df[column_name] = df[column_name].apply(lambda x: mean_value if pd.isna(x) else x)

    # Step 4: For values greater than or equal to the threshold, keep them unchanged (or remove if needed)
    df[column_name] = df[column_name].apply(lambda x: x if x < threshold else None)

    return df


# One time doesnt impute all Na so twice calling the fn
X_train = process_column_with_threshold('Column5', X_train, 100)
X_train = process_column_with_threshold('Column5', X_train, 100)


def impute_with_regression(df, col_to_impute, correlated_col):
    """
    Imputes missing values in col_to_impute using a linear regression model trained on correlated_col.

    Args:
    - df (DataFrame): The DataFrame containing the columns.
    - col_to_impute (str): The column with missing values to impute.
    - correlated_col (str): The highly correlated column to use for prediction.

    Returns:
    - Updated DataFrame with imputed values in col_to_impute.
    """

    # Step 1: Separate rows where both columns have no missing values
    valid_data = df[[col_to_impute, correlated_col]].dropna()

    # Step 2: Fit linear regression model to predict col_to_impute using correlated_col
    lr_model = LinearRegression()
    lr_model.fit(valid_data[correlated_col].values.reshape(-1, 1), valid_data[col_to_impute].values)

    # Step 3: Predict missing values for col_to_impute
    missing_mask = df[col_to_impute].isna() & df[correlated_col].notna()
    df.loc[missing_mask, col_to_impute] = lr_model.predict(df.loc[missing_mask, correlated_col].values.reshape(-1, 1))

    # Step 4: (Optional) Fill remaining missing values with the column mean
    df[col_to_impute].fillna(df[col_to_impute].mean(), inplace=True)

    return df

# Call the function to impute missing values in Column4 using Column3
X_train = impute_with_regression(X_train, 'Column4', 'Column3')

X_train = impute_with_regression(X_train, 'Column3', 'Column4')


def impute_with_mean_excluding_threshold(df, column_name, threshold):
    """
    Imputes missing values in a column with the mean, excluding values below a specified threshold.

    Args:
    - df (DataFrame): The DataFrame containing the column.
    - column_name (str): The column to process.
    - threshold (float or int): The threshold below which values will be ignored when calculating the mean.

    Returns:
    - Updated DataFrame with NaN values imputed in the specified column.
    """

    # Step 1: Filter out values below the threshold for mean calculation
    valid_values = df.loc[df[column_name] >= threshold, column_name]

    # Step 2: Compute the mean of the valid values
    mean_value = valid_values.mean()

    # Step 3: Impute NaN values with the computed mean
    df[column_name].fillna(mean_value, inplace=True)

    return df

# Call the function for Column15 with a threshold of -10
X_train = impute_with_mean_excluding_threshold(X_train, 'Column15', -10)


X_train = process_column_with_threshold('Column8', X_train, 20)
X_train = process_column_with_threshold('Column8', X_train, 20)


X_train = process_column_with_threshold('Column6', X_train, 3.5)
X_train = process_column_with_threshold('Column6', X_train, 3.5)

def impute_with_mean_of_75th_percentile(df, column_name):
    """
    Imputes missing values in a column with the mean of the values up to the 75th percentile.

    Args:
    - df (DataFrame): The DataFrame containing the column.
    - column_name (str): The column to process.

    Returns:
    - Updated DataFrame with NaN values imputed in the specified column.
    """

    # Step 1: Calculate the 75th percentile value
    percentile_75_value = df[column_name].quantile(0.75)

    # Step 2: Filter the column values below or equal to the 75th percentile
    values_below_75th = df.loc[df[column_name] <= percentile_75_value, column_name]

    # Step 3: Calculate the mean of those values
    mean_value = values_below_75th.mean()

    # Step 4: Impute NaN values with the calculated mean
    df[column_name].fillna(mean_value, inplace=True)

    return df

# Call the function for Column0
X_train = impute_with_mean_of_75th_percentile(X_train, 'Column0')
X_train = impute_with_mean_of_75th_percentile(X_train, 'Column0')


ids_to_remove = X_train.loc[X_train['Column26'] == 1, 'ID'].tolist()

X_train = X_train[~X_train['ID'].isin(ids_to_remove)].copy()
Y_train = Y_train[~Y_train['ID'].isin(ids_to_remove)].copy()

X_train.drop(columns=['Column26'], inplace=True)


X_train['Column24']=X_train['Column2']*X_train['Column7']


X_train['Column25']=X_train['Column7']*X_train['Column8']


X_train['Column26'] = np.where(X_train['Column0'] > 0,
                               X_train['Column0'] * X_train['Column7'],
                               X_train['Column7'])

X_train['Column27'] = np.where(X_train['Column0'] > 0,
                               X_train['Column0'] * X_train['Column14'],
                               X_train['Column14'])


X_train['Column28'] = X_train['Column12']+X_train['Column2']

X_train['Column29'] = X_train['Column14']+X_train['Column12']

# Modelling

# with open('scaler.pkl', 'rb') as file:
#     loaded_scaler = pickle.load(file)

X_test_scaled = loaded_scaler.transform(X_train.drop(columns=['ID']))

Y_test_fixed = pd.to_numeric(Y_train['target'], errors='coerce').astype(int)

# with open('model.pkl', 'rb') as file:
#     model = pickle.load(file)

y_pred_test = model.predict(X_test_scaled, num_iteration=model.best_iteration)

y_pred_test_binary = (y_pred_test > 0.5).astype(int)


print("\nTest Accuracy (LightGBM):", accuracy_score(Y_test_fixed, y_pred_test_binary))
print("\nConfusion Matrix (Test Data, LightGBM):")
print(confusion_matrix(Y_test_fixed, y_pred_test_binary))

# Additional metrics
print("Recall (Test Data, LightGBM):", recall_score(Y_test_fixed, y_pred_test_binary))
print("Precision (Test Data, LightGBM):", precision_score(Y_test_fixed, y_pred_test_binary))
print("F1 Score (Test Data, LightGBM):", f1_score(Y_test_fixed, y_pred_test_binary))
print("AUC-ROC Score (Test Data, LightGBM):", roc_auc_score(Y_test_fixed, y_pred_test))

# Compute the confusion matrix
conf_matrix = confusion_matrix(Y_test_fixed, y_pred_test_binary)

# Plot the confusion matrix
plt.figure(figsize=(6, 4))  # Set the figure size
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', cbar=False,
            xticklabels=['Predicted 0', 'Predicted 1'],
            yticklabels=['Actual 0', 'Actual 1'])

# Add labels and title
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.title('Confusion Matrix')

# Show the plot
plt.show()

